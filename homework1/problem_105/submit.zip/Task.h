class Task{
	
	public:
	char name[30];
	int dur;
	int task_num;
	int task_cap;
	Task(char s[], int d, int n, int m);
};